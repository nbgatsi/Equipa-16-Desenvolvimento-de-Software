﻿using System;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameControlApp
{
    // Abstração do cliente de comunicação com o Stride3D
    public class Stride3DEngineClient
    {
        private bool isConnected;

        public Stride3DEngineClient()
        {
            // Aqui você inicializaria conexão real (sockets, RPC, etc.)
            isConnected = false;
        }

        public async Task ConnectAsync()
        {
            // Simula delay de conexão
            await Task.Delay(500);
            isConnected = true;
        }

        public bool IsConnected => isConnected;

        public async Task<string> SendCommandAsync(string command)
        {
            if (!isConnected)
                throw new InvalidOperationException("Não conectado ao Stride3D.");

            // Simula envio e processamento no motor
            await Task.Delay(300);
            // Aqui, receba e retorne a resposta real
            return $"(Resposta simulada) Comando '{command}' executado.";
        }

        public void Disconnect()
        {
            // Fecha conexão se necessário
            isConnected = false;
        }
    }

    // Controlador separa responsabilidades de UI e lógica
    public class GameController
    {
        private readonly Stride3DEngineClient engine;
        public BindingList<string> LogEntries { get; } = new BindingList<string>();

        public GameController()
        {
            engine = new Stride3DEngineClient();
        }

        public async Task InitializeAsync()
        {
            AddLog("Sistema: Conectando ao Stride3D...");
            try
            {
                await engine.ConnectAsync();
                AddLog("Sistema: Conectado com sucesso.");
            }
            catch (Exception ex)
            {
                AddLog($"Erro ao conectar: {ex.Message}");
                throw;
            }
        }

        public async Task SendAsync(string command)
        {
            if (string.IsNullOrWhiteSpace(command))
                return;

            AddLog($"Usuário: {command}");
            try
            {
                var response = await engine.SendCommandAsync(command);
                AddLog($"Stride3D: {response}");
            }
            catch (Exception ex)
            {
                AddLog($"Erro: {ex.Message}");
            }
            finally
            {
                // Limita histórico a 200 entradas
                if (LogEntries.Count > 200)
                    LogEntries.RemoveAt(LogEntries.Count - 1);
            }
        }

        private void AddLog(string message)
        {
            // Insere na posição 0 para mostrar as mais recentes no topo
            LogEntries.Insert(0, $"[{DateTime.Now:HH:mm:ss}] {message}");
        }
    }

    public class GameControlForm : Form
    {
        private readonly GameController controller = new GameController();
        private TextBox inputBox;
        private Button sendButton;
        private Button clearButton;
        private ListBox logBox;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel statusLabel;

        public GameControlForm()
        {
            this.Text = "Protótipo - Controle de Jogo";
            this.Width = 600;
            this.Height = 450;

            InitializeComponents();

            // Vincula o log ao ListBox
            logBox.DataSource = controller.LogEntries;
        }

        private async void InitializeComponents()
        {
            inputBox = new TextBox() { Top = 20, Left = 20, Width = 420 };
            inputBox.KeyDown += async (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    await SendCommandAsync();
                }
            };

            sendButton = new Button() { Text = "Enviar", Top = 20, Left = 460, Width = 100 };
            sendButton.Click += async (s, e) => await SendCommandAsync();

            clearButton = new Button() { Text = "Limpar Log", Top = 60, Left = 460, Width = 100 };
            clearButton.Click += (s, e) => controller.LogEntries.Clear();

            logBox = new ListBox() { Top = 100, Left = 20, Width = 540, Height = 280 };

            statusStrip = new StatusStrip();
            statusLabel = new ToolStripStatusLabel() { Text = "Inicializando..." };
            statusStrip.Items.Add(statusLabel);

            this.Controls.AddRange(new Control[] { inputBox, sendButton, clearButton, logBox, statusStrip });

            // Conecta ao Stride3D ao inicializar
            try
            {
                await controller.InitializeAsync();
                statusLabel.Text = "Conectado ao Stride3D";
            }
            catch
            {
                statusLabel.Text = "Falha na conexão";
                sendButton.Enabled = false;
                inputBox.Enabled = false;
            }
        }

        private async Task SendCommandAsync()
        {
            sendButton.Enabled = false;
            inputBox.Enabled = false;
            statusLabel.Text = "Enviando comando...";

            var cmd = inputBox.Text.Trim();
            await controller.SendAsync(cmd);

            inputBox.Clear();
            statusLabel.Text = "Pronto";
            sendButton.Enabled = true;
            inputBox.Enabled = true;
            inputBox.Focus();
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GameControlForm());
        }
    }
}
