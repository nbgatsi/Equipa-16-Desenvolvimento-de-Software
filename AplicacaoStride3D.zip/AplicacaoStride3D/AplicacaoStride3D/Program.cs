﻿using System;
using System.ComponentModel;
using System.Resources;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AplicacaoStride3D.Properties;

namespace GameControlApp
{
    public interface ILogItem
    {
        string Tipo { get; }
        string Mensagem { get; }
        DateTime Timestamp { get; }
    }

    public class LogItem : ILogItem
    {
        public string Tipo { get; }
        public string Mensagem { get; }
        public DateTime Timestamp { get; }

        public LogItem(string tipo, string mensagem)
        {
            Tipo = tipo;
            Mensagem = mensagem;
            Timestamp = DateTime.Now;
        }

        public override string ToString() => $"[{Timestamp:HH:mm:ss}] {Tipo}: {Mensagem}";
    }

    public interface IStride3DEngineClient : IDisposable
    {
        Task ConnectAsync(CancellationToken cancellationToken = default);
        bool IsConnected { get; }
        Task<string> SendCommandAsync(string command, CancellationToken cancellationToken = default);
        void Disconnect();
    }

    public class Stride3DEngineClient : IStride3DEngineClient
    {
        private bool isConnected;
        private bool disposed;

        public Stride3DEngineClient() => isConnected = false;

        public async Task ConnectAsync(CancellationToken cancellationToken = default)
        {
            await Task.Delay(500, cancellationToken);
            isConnected = true;
        }

        public bool IsConnected => isConnected;

        public async Task<string> SendCommandAsync(string command, CancellationToken cancellationToken = default)
        {
            if (!isConnected)
                throw new InvalidOperationException("Não conectado ao Stride3D.");

            await Task.Delay(300, cancellationToken);
            return $"(Resposta simulada) Comando '{command}' executado.";
        }

        public void Disconnect() => isConnected = false;

        public void Dispose()
        {
            if (disposed) return;
            Disconnect();
            disposed = true;
        }
    }

    public class GameController : IDisposable
    {
        private readonly IStride3DEngineClient engine;
        private readonly SynchronizationContext syncContext = SynchronizationContext.Current;
        public BindingList<ILogItem> LogEntries { get; } = new BindingList<ILogItem>();

        public GameController(IStride3DEngineClient engineClient)
        {
            engine = engineClient;
        }

        public async Task InitializeAsync(CancellationToken cancellationToken = default)
        {
            AddLog(Resources.LogTypeSystem, Resources.StatusInitializing);
            try
            {
                await engine.ConnectAsync(cancellationToken);
                AddLog(Resources.LogTypeSystem, Resources.StatusConnected);
            }
            catch (OperationCanceledException)
            {
                AddLog(Resources.LogTypeSystem, "Conexão cancelada.");
                throw;
            }
            catch (Exception ex)
            {
                AddLog(Resources.LogTypeError, $"Erro ao conectar: {ex.Message}");
                throw;
            }
        }

        public async Task SendAsync(string command, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(command))
                return;

            AddLog(Resources.LogTypeUser, command);
            try
            {
                var response = await engine.SendCommandAsync(command, cancellationToken);
                AddLog(Resources.LogTypeEngine, response);
            }
            catch (Exception ex)
            {
                AddLog(Resources.LogTypeError, $"Erro ao enviar comando: {ex.GetType().Name} - {ex.Message}");
            }
            finally
            {
                if (LogEntries.Count > 200)
                {
                    for (int i = LogEntries.Count - 1; i >= 200; i--)
                        LogEntries.RemoveAt(i);
                }
            }
        }

        private void AddLog(string tipo, string mensagem)
        {
            var log = new LogItem(tipo, mensagem);
            syncContext.Post(_ => LogEntries.Insert(0, log), null);
        }

        public void Dispose()
        {
            engine.Dispose();
        }
    }

    public class GameControlForm : Form
    {
        private readonly GameController controller;
        private readonly CancellationTokenSource cts = new CancellationTokenSource();
        private TextBox inputBox;
        private Button sendButton;
        private Button clearButton;
        private DataGridView logGrid;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel statusLabel;

        public GameControlForm()
        {
            Text = Resources.Title;
            Width = 600;
            Height = 450;

            controller = new GameController(new Stride3DEngineClient());

            InitializeComponents();
            logGrid.DataSource = controller.LogEntries;
        }

        private async void InitializeComponents()
        {
            inputBox = new TextBox { Top = 20, Left = 20, Width = 420 };
            inputBox.KeyDown += async (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    await SendCommandAsync();
                }
            };

            sendButton = new Button { Text = Resources.ButtonSend, Top = 20, Left = 460, Width = 100 };
            sendButton.Click += async (s, e) => await SendCommandAsync();

            clearButton = new Button { Text = Resources.ButtonClear, Top = 60, Left = 460, Width = 100 };
            clearButton.Click += (s, e) => controller.LogEntries.Clear();

            logGrid = new DataGridView
            {
                Top = 100,
                Left = 20,
                Width = 540,
                Height = 280,
                AutoGenerateColumns = false,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            logGrid.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Timestamp",
                HeaderText = "Hora",
                Width = 80,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "HH:mm:ss" }
            });
            logGrid.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Tipo",
                HeaderText = "Tipo",
                Width = 100
            });
            logGrid.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Mensagem",
                HeaderText = "Mensagem",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });

            statusStrip = new StatusStrip();
            statusLabel = new ToolStripStatusLabel { Text = Resources.StatusInitializing };
            statusStrip.Items.Add(statusLabel);

            Controls.AddRange(new Control[] { inputBox, sendButton, clearButton, logGrid, statusStrip });

            try
            {
                await controller.InitializeAsync(cts.Token);
                statusLabel.Text = Resources.StatusConnected;
            }
            catch
            {
                statusLabel.Text = Resources.StatusFailed;
                sendButton.Enabled = false;
                inputBox.Enabled = false;
            }
        }

        private async Task SendCommandAsync()
        {
            try
            {
                sendButton.Enabled = false;
                inputBox.Enabled = false;
                statusLabel.Text = Resources.StatusSending;

                var cmd = inputBox.Text.Trim();
                await controller.SendAsync(cmd, cts.Token);
            }
            finally
            {
                inputBox.Clear();
                statusLabel.Text = Resources.StatusReady;
                sendButton.Enabled = true;
                inputBox.Enabled = true;
                inputBox.Focus();
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            cts.Cancel();
            cts.Dispose();
            controller.Dispose();
            base.OnFormClosing(e);
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GameControlForm());
        }
    }
}
